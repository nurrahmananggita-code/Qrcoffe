"use strict";
       
      var MENU = [
        {id:1, name:"Kopi Susu Gula Aren", cat:"kopi", price:24000, img:"../assets/kopi-susu-gula-aren.jpg", rating:"4.9",
         desc:"Espresso, susu segar, gula aren cair.", chips:["Kopi","Kafein sedang"],
         tags:["kopi","dingin","manis","kafein","susu","creamy"]},
        {id:2, name:"Americano", cat:"kopi", price:20000, img:"../assets/americano.jpg", rating:"4.7",
         desc:"Espresso dengan air panas, menghasilkan rasa kopi yang kuat.", chips:["Kopi","Kafein tinggi"],
         tags:["kopi","dingin","kafein","pahit","kuat","segar"]},
        {id:3, name:"Kopi Tubruk", cat:"kopi", price:15000, img:"../assets/kopi-tubruk.jpg", rating:"4.8",
         desc:"Kopi tubruk tradisional, disajikan panas.", chips:["Kopi","Kafein tinggi"],
         tags:["kopi","panas","kafein","kuat","hangat"]},
        {id:4, name:"Matcha Latte", cat:"nonkopi", price:25000, img:"../assets/matcha-latte.jpg", rating:"4.9",
         desc:"Matcha premium di-whisk segar, dipadu susu creamy dan manis ringan.", chips:["Non-Kopi","Creamy"],
         tags:["matcha","susu","dingin","manis","lembut","creamy"]},
        {id:5, name:"Cokelat Klasik", cat:"nonkopi", price:22000, img:"../assets/cokelat-klasik.jpg", rating:"4.8",
         desc:"Cokelat Belgia hangat dengan marshmallow meleleh di atasnya.", chips:["Non-Kopi","Hangat"],
         tags:["cokelat","hangat","manis","lembut","creamy","panas"]},
        {id:6, name:"Nasi Goreng Kampung", cat:"makanan", price:30000, img:"../assets/nasi-goreng-kampung.jpg", rating:"4.8",
         desc:"Nasi goreng kecap manis, telur mata sapi, kerupuk, dan timun segar.", chips:["Makanan","Pedas"],
         tags:["berat","kenyang","nasi","pedas"]},
        {id:7, name:"Chicken Katsu Rice", cat:"makanan", price:32000, img:"../assets/chicken-katsu-rice.jpg", rating:"4.9",
         desc:"Ayam katsu renyah, saus tonkatsu, nasi hangat, dan salad segar.", chips:["Makanan","Gurih"],
         tags:["berat","kenyang","nasi","ayam","gurih"]},
        {id:8, name:"Spaghetti Aglio e Olio", cat:"makanan", price:34000, img:"../assets/spaghetti-aglio-e-olio.jpg", rating:"4.7",
         desc:"Spaghetti bawang putih, cabai kering, parsley, dan parmesan.", chips:["Makanan","Pedas"],
         tags:["berat","pasta","pedas","gurih"]},
        {id:9, name:"Kentang Truffle", cat:"camilan", price:20000, img:"../assets/kentang-truffle.jpg", rating:"4.8",
         desc:"Kentang goreng renyah, minyak truffle, parmesan, dan saus aioli.", chips:["Camilan","Gurih"],
         tags:["ringan","gurih","camilan","kentang"]},
        {id:10, name:"Butter Croissant", cat:"camilan", price:18000, img:"../assets/butter-croissant.jpg", rating:"4.9",
         desc:"Croissant 27 lapis mentega premium. Renyah di luar, lembut di dalam.", chips:["Camilan","Pastry"],
         tags:["ringan","camilan","manis","pastry"]},
        {id:11, name:"Basque Cheesecake", cat:"dessert", price:28000, img:"../assets/basque-cheesecake.jpg", rating:"5.0",
         desc:"Cheesecake gosong khas San Sebastian: karamel di luar, creamy di tengah.", chips:["Dessert","Keju"],
         tags:["manis","dessert","keju","lembut","creamy"]},
        {id:12, name:"Fudgy Brownies", cat:"dessert", price:15000, img:"../assets/fudgy-brownies.jpg", rating:"4.8",
         desc:"Brownies cokelat pekat dengan crackly top, disajikan hangat.", chips:["Dessert","Cokelat"],
         tags:["manis","dessert","cokelat","hangat"]}
      ];
      var CATS = [
        {id:"semua", label:"Semua"},
        {id:"kopi", label:"Kopi"},
        {id:"nonkopi", label:"Non-kopi"},
        {id:"makanan", label:"Makanan"},
        {id:"camilan", label:"Camilan"},
        {id:"dessert", label:"Dessert"}
      ];
      var OCCUPIED = [3, 7];
      var DRINK_CATS = ["kopi", "nonkopi"];

       
      var state = {
        name: "", table: null, cart: [], cat: "semua", query: "",
        payMethod: "qris", orderNo: null, trxNo: null, orderNote: "",
        countdownTimer: null, statusTimers: [], aiText: ""
      };
      var detail = { item: null, size: "Regular", sugar: "Normal", qty: 1 };
      var currentScreen = "screen-welcome";

       
      function $(id){ return document.getElementById(id); }
      function fmt(n){ return "Rp" + n.toLocaleString("id-ID"); }
      function byId(id){ for (var i=0;i<MENU.length;i++) if (MENU[i].id===id) return MENU[i]; return null; }
      function cartCount(){ return state.cart.reduce(function(a,c){return a+c.qty;},0); }
      function cartSubtotal(){ return state.cart.reduce(function(a,c){return a+c.unitPrice*c.qty;},0); }
      function cartTax(){ return Math.round(cartSubtotal()*0.10); }
      function cartTotal(){ return cartSubtotal()+cartTax(); }
      var toastTimer = null;
      function showToast(msg){
        $("toast-text").textContent = msg;
        $("toast").classList.add("show");
        clearTimeout(toastTimer);
        toastTimer = setTimeout(function(){ $("toast").classList.remove("show"); }, 1900);
      }
      var reduceMotion = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

       
      function go(screenId, dir){
        if (screenId === currentScreen) return;
        var from = $(currentScreen), to = $(screenId);
        var inCls = dir === "back" ? "anim-in-back" : dir === "fade" ? "anim-in-fade" : "anim-in-fwd";
        var outCls = dir === "back" ? "anim-out-back" : dir === "fade" ? "" : "anim-out-fwd";
        to.classList.remove("anim-in-fwd","anim-in-back","anim-in-fade","anim-out-fwd","anim-out-back");
        to.classList.add("active");
        to.scrollTop = 0;
        void to.offsetWidth;
        to.classList.add(inCls);
        if (from && from !== to && outCls){
          from.classList.remove("anim-in-fwd","anim-in-back","anim-in-fade");
          from.classList.add(outCls);
          (function(f, oc){
            setTimeout(function(){ f.classList.remove("active", oc); }, 470);
          })(from, outCls);
        } else if (from && from !== to){
          from.classList.remove("active");
        }
        currentScreen = screenId;
        syncCartBar();
      }

       
      var transBusy = false;
      function playTransition(opts, done){
        if (transBusy){ if (done) done(); return; }
        transBusy = true;
        var ov = $("trans-overlay"), stepEl = $("trans-step"), fill = $("trans-fill");
        $("trans-title").textContent = opts.title || "Sebentar ya…";
        var steps = opts.steps && opts.steps.length ? opts.steps : ["Menyiapkan…"];
        var dur = reduceMotion ? 500 : (opts.duration || 1300);
        fill.style.transition = "none"; fill.style.width = "0%";
        stepEl.textContent = steps[0]; stepEl.style.opacity = 1;
        ov.classList.add("show"); ov.setAttribute("aria-hidden", "false");
        void fill.offsetWidth;
        fill.style.transition = "width " + dur + "ms cubic-bezier(.3,.7,.3,1)";
        fill.style.width = "100%";
        var stepTimer = null;
        if (steps.length > 1 && !reduceMotion){
          var idx = 0;
          stepTimer = setInterval(function(){
            idx++;
            if (idx >= steps.length){ clearInterval(stepTimer); stepTimer = null; return; }
            stepEl.style.opacity = 0;
            setTimeout(function(){ stepEl.textContent = steps[idx]; stepEl.style.opacity = 1; }, 160);
          }, Math.floor(dur / steps.length));
        }
        var switched = false;
        function swap(){ if (!switched){ switched = true; if (done) done(); } }
        setTimeout(swap, Math.floor(dur * 0.8));
        setTimeout(function(){
          if (stepTimer) clearInterval(stepTimer);
          swap();
          ov.classList.remove("show"); ov.setAttribute("aria-hidden", "true");
          transBusy = false;
        }, dur + 140);
      }

       
      (function buildTables(){
        var grid = $("table-grid"), html = "";
        for (var t=1; t<=10; t++){
          var occ = OCCUPIED.indexOf(t) !== -1;
          html += '<button class="table-cell' + (occ ? " occupied" : "") + '" data-table="' + t + '"' + (occ ? " disabled" : "") + '>' +
            '<span class="t-num">' + t + '</span><span class="t-cap">' + (occ ? "Terisi" : "Kosong") + '</span></button>';
        }
        grid.innerHTML = html;
        grid.addEventListener("click", function(e){
          var btn = e.target.closest(".table-cell");
          if (!btn || btn.disabled) return;
          state.table = parseInt(btn.dataset.table, 10);
          var cells = grid.querySelectorAll(".table-cell");
          for (var i=0;i<cells.length;i++) cells[i].classList.toggle("selected", parseInt(cells[i].dataset.table,10)===state.table);
          $("welcome-meja").textContent = "Meja " + state.table;
          validateWelcome();
        });
      })();
      function validateWelcome(){
        var nameOk = $("input-name").value.trim().length >= 2;
        var ok = nameOk && state.table !== null;
        $("btn-start").disabled = !ok;
        var hint = $("form-hint");
        if (!nameOk && state.table === null){ hint.textContent = "Isi namamu (min. 2 huruf) dan pilih satu meja untuk mulai."; hint.className = "form-hint"; }
        else if (!nameOk){ hint.textContent = "Namamu belum diisi. Nama ini yang dipanggil barista nanti."; hint.className = "form-hint warn"; }
        else if (state.table === null){ hint.textContent = "Pilih dulu mejamu, biar pesanan tidak nyasar."; hint.className = "form-hint warn"; }
        else { hint.textContent = "Siap. Meja " + state.table + " untuk " + $("input-name").value.trim() + "."; hint.className = "form-hint"; }
      }
      $("input-name").addEventListener("input", validateWelcome);
      validateWelcome();
      $("btn-start").addEventListener("click", function(){
        state.name = $("input-name").value.trim();
        $("menu-ctx").textContent = "Meja " + state.table + " · Halo, " + state.name + " 👋";
        playTransition({
          title: "Siap, " + state.name + "!",
          steps: ["Meja " + state.table + " disiapkan…", "Menghubungi dapur…", "Menu sudah siap, silakan pilih"],
          duration: 1550
        }, function(){ go("screen-menu", "fwd"); });
      });

       
      (function buildCats(){
        var wrap = $("cats"), html = "";
        CATS.forEach(function(c){
          html += '<button class="cat-pill' + (c.id===state.cat ? " active" : "") + '" data-cat="' + c.id + '">' + c.label + '</button>';
        });
        wrap.innerHTML = html;
        wrap.addEventListener("click", function(e){
          var btn = e.target.closest(".cat-pill"); if (!btn) return;
          state.cat = btn.dataset.cat;
          var pills = wrap.querySelectorAll(".cat-pill");
          for (var i=0;i<pills.length;i++) pills[i].classList.toggle("active", pills[i].dataset.cat===state.cat);
          renderMenu();
        });
      })();
      $("input-search").addEventListener("input", function(e){ state.query = e.target.value.trim().toLowerCase(); renderMenu(); });
      function filteredMenu(){
        return MENU.filter(function(m){
          var okCat = state.cat === "semua" || m.cat === state.cat;
          var okQ = !state.query || m.name.toLowerCase().indexOf(state.query) !== -1 || m.desc.toLowerCase().indexOf(state.query) !== -1;
          return okCat && okQ;
        });
      }
      function imgShell(m, cls){
        return '<span class="img-shell ' + (cls || "") + '" data-shell><img src="' + m.img + '" alt="' + m.name + '" loading="lazy" /></span>';
      }
      function renderMenu(){
        var list = filteredMenu();
        $("menu-grid").innerHTML = list.map(function(m){
          return '<button class="menu-row" data-open="' + m.id + '">' +
            imgShell(m) +
            '<span class="m-info"><h4>' + m.name + '</h4><p>' + m.desc + '</p>' +
            '<span class="m-foot"><span class="price">' + fmt(m.price) + '</span><span class="m-rate">★ ' + m.rating + '</span></span></span>' +
            '<span class="round-add" data-add="' + m.id + '" role="button" aria-label="Tambah ' + m.name + '">' +
            '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>' +
            '</span></button>';
        }).join("");
        $("menu-empty").style.display = list.length ? "none" : "block";
      }
      $("menu-grid").addEventListener("click", function(e){
        var add = e.target.closest("[data-add]");
        if (add){ e.stopPropagation(); quickAdd(parseInt(add.dataset.add,10)); return; }
        var card = e.target.closest("[data-open]");
        if (card) openDetail(parseInt(card.dataset.open,10));
      });
      function quickAdd(id){
        var m = byId(id);
        var isDrink = DRINK_CATS.indexOf(m.cat) !== -1;
        pushCart(m, isDrink ? "Regular" : null, isDrink ? "Normal" : null, "", 1);
        showToast(m.name + " ditambahkan");
      }
      function pushCart(item, size, sugar, note, qty){
        var key = item.id + "|" + (size||"") + "|" + (sugar||"") + "|" + note.trim().toLowerCase();
        var unit = item.price + (size === "Large" ? 5000 : 0);
        for (var i=0;i<state.cart.length;i++){
          if (state.cart[i].key === key){ state.cart[i].qty += qty; syncCartBar(); return; }
        }
        state.cart.push({ key:key, id:item.id, name:item.name, img:item.img, size:size, sugar:sugar, note:note.trim(), qty:qty, unitPrice:unit });
        syncCartBar();
      }
      function syncCartBar(){
        var n = cartCount();
        $("cart-bar-count").textContent = n + " item";
        $("cart-bar-total").textContent = fmt(cartTotal());
        var onShop = currentScreen === "screen-menu" || currentScreen === "screen-ai-result";
        $("cart-bar").classList.toggle("show", onShop && state.cart.length > 0);
      }
      $("cart-bar").addEventListener("click", function(){ renderCart(); go("screen-cart", "fwd"); });

       
      (function promoCarousel(){
        var track = $("promo-track"), dotsWrap = $("promo-dots");
        var total = track.children.length, cur = 0, timer = null, resumeTimer = null, swiped = false;
        var html = "";
        for (var i=0;i<total;i++) html += '<button data-dot="' + i + '" aria-label="Ke banner ' + (i+1) + '"></button>';
        dotsWrap.innerHTML = html;
        var dots = dotsWrap.querySelectorAll("button");
        function show(n){
          cur = (n + total) % total;
          track.style.transform = "translateX(-" + (cur * 100) + "%)";
          for (var j=0;j<dots.length;j++) dots[j].classList.toggle("on", j === cur);
          for (var k=0;k<track.children.length;k++) track.children[k].classList.toggle("is-on", k === cur);
        }
        function stopAuto(){ if (timer){ clearInterval(timer); timer = null; } }
        function startAuto(){
          stopAuto();
          if (resumeTimer){ clearTimeout(resumeTimer); resumeTimer = null; }
          timer = setInterval(function(){ show(cur + 1); }, 4000);
        }
        function pauseAuto(){
          stopAuto();
          if (resumeTimer) clearTimeout(resumeTimer);
          resumeTimer = setTimeout(startAuto, 6000);
        }
        dotsWrap.addEventListener("click", function(e){
          var d = e.target.closest("[data-dot]"); if (!d) return;
          show(parseInt(d.dataset.dot, 10)); startAuto();
        });
        track.addEventListener("click", function(e){
          if (swiped) return;
          var s = e.target.closest("[data-banner-open]"); if (!s) return;
          openDetail(parseInt(s.dataset.bannerOpen, 10));
        });
        var startX = null;
        track.addEventListener("touchstart", function(e){ startX = e.touches[0].clientX; pauseAuto(); }, { passive:true });
        track.addEventListener("touchend", function(e){
          if (startX === null) return;
          var dx = e.changedTouches[0].clientX - startX; startX = null;
          if (Math.abs(dx) > 42){
            swiped = true;
            setTimeout(function(){ swiped = false; }, 350);
            show(cur + (dx < 0 ? 1 : -1));
          }
          pauseAuto();
        }, { passive:true });
        if (window.matchMedia && window.matchMedia("(pointer: fine)").matches){
          $("promo").addEventListener("mouseenter", stopAuto);
          $("promo").addEventListener("mouseleave", startAuto);
        }
        show(0); startAuto();
      })();

       
      function openSheet(){ $("sheet-backdrop").classList.add("show"); $("detail-sheet").classList.add("show"); }
      function closeSheet(){ $("sheet-backdrop").classList.remove("show"); $("detail-sheet").classList.remove("show"); }
      $("sheet-backdrop").addEventListener("click", closeSheet);
      $("d-close").addEventListener("click", closeSheet);
      function openDetail(id){
        var m = byId(id); if (!m) return;
        detail = { item: m, size: "Regular", sugar: "Normal", qty: 1 };
        $("d-name").textContent = m.name;
        $("d-desc").textContent = m.desc;
        $("d-head-price").textContent = fmt(m.price);
        $("d-chips").innerHTML = m.chips.map(function(c){ return '<span class="chip-info">' + c + '</span>'; }).join("");
        $("d-note").value = "";
        var isDrink = DRINK_CATS.indexOf(m.cat) !== -1;
        $("d-size-wrap").style.display = isDrink ? "block" : "none";
        $("d-sugar-wrap").style.display = isDrink ? "block" : "none";
        syncSeg($("d-size"), "Regular"); syncSeg($("d-sugar"), "Normal");
        updateDetailUI();
        openSheet();
      }
      function syncSeg(wrap, val){
        var btns = wrap.querySelectorAll("button");
        for (var i=0;i<btns.length;i++) btns[i].classList.toggle("sel", btns[i].dataset.val === val);
      }
      function segHandler(wrapId, field){
        $(wrapId).addEventListener("click", function(e){
          var btn = e.target.closest("button"); if (!btn) return;
          detail[field] = btn.dataset.val; syncSeg($(wrapId), detail[field]); updateDetailUI();
        });
      }
      segHandler("d-size", "size"); segHandler("d-sugar", "sugar");
      $("d-minus").addEventListener("click", function(){ if (detail.qty > 1){ detail.qty--; updateDetailUI(); } });
      $("d-plus").addEventListener("click", function(){ if (detail.qty < 20){ detail.qty++; updateDetailUI(); } });
      function updateDetailUI(){
        $("d-qty").textContent = detail.qty;
        var unit = detail.item.price + (detail.size === "Large" ? 5000 : 0);
        $("d-total").textContent = fmt(unit * detail.qty);
        $("d-head-price").textContent = fmt(unit);
      }
      $("d-add").addEventListener("click", function(){
        var isDrink = DRINK_CATS.indexOf(detail.item.cat) !== -1;
        pushCart(detail.item, isDrink ? detail.size : null, isDrink ? detail.sugar : null, $("d-note").value, detail.qty);
        closeSheet();
        showToast(detail.item.name + " ditambahkan");
      });

       
      $("btn-open-ai").addEventListener("click", function(){ go("screen-ai", "fwd"); });
      document.querySelectorAll("[data-back]").forEach(function(btn){
        btn.addEventListener("click", function(){ go(btn.dataset.back, "back"); });
      });
      $("ai-examples").addEventListener("click", function(e){
        var btn = e.target.closest("button"); if (!btn) return;
        $("ai-input").value = btn.dataset.text;
        var all = $("ai-examples").querySelectorAll("button");
        for (var i=0;i<all.length;i++) all[i].classList.toggle("sel", all[i] === btn);
      });
      var AI_RULES = [
        { words:["kafein"], tag:"kafein" },
        { words:["ngantuk","lembur","begadang","melek","kerja","tugas","nendang","kuat"], tag:"kafein" },
        { words:["dingin","segar","panas","gerah","haus"], tag:"dingin" },
        { words:["manis","gula","sweet"], tag:"manis" },
        { words:["lapar","laper","kenyang","makan"], tag:"berat" },
        { words:["santai","ngobrol","nemenin","ringan","camilan","snack"], tag:"ringan" },
        { words:["cokelat","coklat"], tag:"cokelat" },
        { words:["matcha"], tag:"matcha" },
        { words:["gurih","asin"], tag:"gurih" },
        { words:["creamy","lembut","susu"], tag:"creamy" },
        { words:["hangat"], tag:"hangat" }
      ];
      function runAI(){
        var raw = $("ai-input").value.trim();
        var text = raw.toLowerCase();
        if (text.length < 3){ showToast("Tulis dulu ceritamu, atau pilih contohnya"); return; }
        state.aiText = raw;
        playTransition({
          title: "AI Barista lagi mikir…",
          steps: ["Membaca ceritamu…", "Mencocokkan dengan menu…"],
          duration: 1500
        }, function(){
          renderAIResult(raw, text);
          go("screen-ai-result", "fwd");
        });
      }
      $("btn-ai-go").addEventListener("click", runAI);
      $("btn-ai-retry").addEventListener("click", function(){ go("screen-ai", "back"); });
      function renderAIResult(raw, text){
        $("ai-quote").textContent = "“" + raw + "”";
        var noCoffee = /(nggak|enggak|tidak|tanpa|bukan)\s*(mau\s*)?kopi/.test(text) || text.indexOf("non-kopi") !== -1 || text.indexOf("non kopi") !== -1;
        var budget = null;
        var bm = text.match(/(\d+)\s*ribu/);
        if (bm) budget = parseInt(bm[1], 10) * 1000;
        var hits = [];
        AI_RULES.forEach(function(rule){
          for (var i=0;i<rule.words.length;i++){
            if (text.indexOf(rule.words[i]) !== -1){ hits.push({ word: rule.words[i], tag: rule.tag }); break; }
          }
        });
        var scores = MENU.map(function(m){ return { item: m, score: 0, word: null }; });
        hits.forEach(function(h){
          scores.forEach(function(s){
            if (s.item.tags.indexOf(h.tag) !== -1){ s.score += 2; if (!s.word) s.word = h.word; }
          });
        });
        if (budget){
          scores.forEach(function(s){ if (s.item.price <= budget) s.score += 1; });
          hits.push({ word: "budget", tag: "budget" });
        }
        if (noCoffee) scores.forEach(function(s){ if (s.item.cat === "kopi") s.score = -99; });
        var ranked = scores.filter(function(s){ return s.score > 0; }).sort(function(a,b){ return b.score - a.score; }).slice(0, 3);
        var fallback = false;
        if (!ranked.length){
          fallback = true;
          ranked = [byId(1), byId(4), byId(11)].map(function(m){ return { item: m, word: null }; });
        }
        $("ai-result").innerHTML = ranked.map(function(r, i){
          var reason;
          if (fallback) reason = "Favorit pengunjung minggu ini.";
          else if (r.word) reason = 'Cocok karena kamu menyebut "' + r.word + '".';
          else if (budget && r.item.price <= budget) reason = 'Cocok karena kamu menyebut "budget".';
          else reason = "Nyambung dengan ceritamu.";
          return '<div class="ai-rec-card' + (i === 0 ? "" : " plain") + '">' +
            (i === 0 ? '<span class="best-badge">★ Paling cocok</span>' : "") +
            '<div class="ai-rec-top">' + imgShell(r.item) +
            '<div><h4>' + r.item.name + '</h4><div class="r-price">' + fmt(r.item.price) + '</div></div></div>' +
            '<p class="reason">' + reason + '</p>' +
            '<button class="btn-light" data-ai-open="' + r.item.id + '" style="justify-content:center;padding:12px 16px;font-size:14px">Lihat &amp; Pesan</button></div>';
        }).join("");
        syncCartBar();
      }
      $("ai-result").addEventListener("click", function(e){
        var btn = e.target.closest("[data-ai-open]"); if (!btn) return;
        openDetail(parseInt(btn.dataset.aiOpen, 10));
      });

       
      function variantText(c){
        var parts = [];
        if (c.size) parts.push(c.size);
        if (c.sugar) parts.push("gula " + c.sugar);
        return parts.join(" · ");
      }
      function renderCart(){
        var wrap = $("cart-items");
        if (!state.cart.length){
          wrap.innerHTML = '<div class="empty-state">Keranjangmu kosong.<br/>Balik ke menu dan pilih sesuatu dulu ya.</div>';
        } else {
          wrap.innerHTML = state.cart.map(function(c, i){
            return '<div class="cart-card">' + imgShell({ img: c.img, name: c.name }) +
              '<div class="c-info"><h5>' + c.name + '</h5>' +
              (variantText(c) ? '<div class="variant">' + variantText(c) + '</div>' : "") +
              (c.note ? '<div class="note-line">“' + c.note + '”</div>' : "") +
              '<div class="c-price">' + fmt(c.unitPrice * c.qty) + '</div></div>' +
              '<div class="mini-stepper"><button data-dec="' + i + '" aria-label="Kurangi">-</button><b>' + c.qty + '</b>' +
              '<button data-inc="' + i + '" aria-label="Tambah">+</button></div></div>';
          }).join("");
        }
        $("cart-cta-total").textContent = fmt(cartSubtotal());
        $("btn-to-checkout").style.opacity = state.cart.length ? "1" : ".45";
      }
      $("cart-items").addEventListener("click", function(e){
        var inc = e.target.closest("[data-inc]"), dec = e.target.closest("[data-dec]");
        if (inc){ state.cart[parseInt(inc.dataset.inc,10)].qty++; }
        else if (dec){
          var i = parseInt(dec.dataset.dec,10);
          state.cart[i].qty--;
          if (state.cart[i].qty <= 0) state.cart.splice(i,1);
        } else return;
        syncCartBar(); renderCart();
      });
      $("btn-to-checkout").addEventListener("click", function(){
        if (!state.cart.length){ showToast("Keranjangmu masih kosong"); return; }
        renderCheckout();
        go("screen-checkout", "fwd");
      });

       
      function renderCheckout(){
        $("co-who").textContent = state.name + " · Meja " + state.table;
        $("co-lines").innerHTML = state.cart.map(function(c){
          return '<div class="sum-row"><span>' + c.qty + '× ' + c.name + '</span><b>' + fmt(c.unitPrice * c.qty) + '</b></div>';
        }).join("");
        $("bill-subtotal").textContent = fmt(cartSubtotal());
        $("bill-tax").textContent = fmt(cartTax());
        $("bill-total").textContent = fmt(cartTotal());
      }
      $("btn-pay").addEventListener("click", function(){
        if (!state.cart.length) return;
        state.orderNote = $("input-order-note").value.trim();
        state.orderNo = "A-" + Math.floor(1000 + Math.random()*9000);
        playTransition({
          title: "Menyiapkan pembayaran…",
          steps: ["Mengecek pesananmu…", "Membuat kode pembayaran…"],
          duration: 1500
        }, function(){ startPayment(); go("screen-payment", "fwd"); });
      });

       
      $("pay-methods").addEventListener("click", function(e){
        var btn = e.target.closest(".pay-opt"); if (!btn) return;
        state.payMethod = btn.dataset.method;
        var opts = $("pay-methods").querySelectorAll(".pay-opt");
        for (var i=0;i<opts.length;i++) opts[i].classList.toggle("sel", opts[i].dataset.method === state.payMethod);
        renderPayArea();
      });
      function startPayment(){
        $("pay-total").textContent = fmt(cartTotal());
        $("pay-order-no").textContent = state.orderNo;
        renderPayArea();
        var remain = 300;
        clearInterval(state.countdownTimer);
        $("qr-countdown").textContent = "05:00";
        state.countdownTimer = setInterval(function(){
          remain--;
          if (remain < 0){ clearInterval(state.countdownTimer); return; }
          var mm = String(Math.floor(remain/60)); if (mm.length < 2) mm = "0" + mm;
          var ss = String(remain % 60); if (ss.length < 2) ss = "0" + ss;
          $("qr-countdown").textContent = mm + ":" + ss;
        }, 1000);
      }
      function renderPayArea(){
        var isQris = state.payMethod === "qris";
        $("qr-wrap").style.display = isQris ? "block" : "none";
        $("va-wrap").style.display = isQris ? "none" : "block";
        if (isQris){
          var box = $("qr-box"); box.innerHTML = "";
          try {
            new QRCode(box, {
              text: "QRIS.MINIMALNGOPI." + state.orderNo + "." + cartTotal(),
              width: 208, height: 208, correctLevel: QRCode.CorrectLevel.M
            });
          } catch (err) {
            box.innerHTML = '<p style="font-size:13px;color:#B3402A;font-weight:700;padding:30px 10px">QR gagal dimuat. Pakai Transfer aja ya.</p>';
          }
        } else {
          var va = "8808" + String(Math.floor(100000000 + Math.random()*900000000));
          $("va-number").textContent = va.replace(/(\d{4})(?=\d)/g, "$1 ");
          $("va-number").dataset.raw = va;
        }
      }
      $("btn-copy-va").addEventListener("click", function(){
        var raw = $("va-number").dataset.raw || "";
        if (navigator.clipboard && raw){
          navigator.clipboard.writeText(raw).then(function(){ showToast("Nomor VA disalin"); }, function(){ showToast(raw); });
        } else showToast(raw);
      });
      $("btn-paid").addEventListener("click", function(){
        clearInterval(state.countdownTimer);
        state.trxNo = "TRX-" + Math.floor(1000 + Math.random()*9000);
        playTransition({
          title: "Mengonfirmasi pembayaran…",
          steps: ["Menghubungi Midtrans…", "Pembayaran diterima", "Pesanan diteruskan ke dapur"],
          duration: 1650
        }, function(){
          $("sc-method").textContent = state.payMethod === "qris" ? "QRIS" : "Transfer";
          $("sc-total").textContent = fmt(cartTotal());
          $("sc-trx").textContent = state.trxNo;
          go("screen-success", "fade");
        });
      });

       
      $("btn-to-status").addEventListener("click", function(){ renderStatus(); go("screen-status", "fwd"); });
      function renderStatus(){
        $("st-sub").textContent = state.orderNo + " · Meja " + state.table;
        $("st-total").textContent = fmt(cartTotal());
        $("status-items").innerHTML = state.cart.map(function(c){
          return '<div class="status-item-row"><span>' + c.qty + '× ' + c.name + '</span><span class="r">' + (c.size || "") + '</span></div>';
        }).join("") +
        (state.orderNote ? '<p class="muted" style="font-size:12.5px;margin:8px 0 0">Catatan: “' + state.orderNote + '”</p>' : "");
        var tl2 = $("tl-2"), tl3 = $("tl-3");
        tl2.className = "tl-step pending"; tl2.querySelector(".tl-dot").textContent = "2";
        tl3.className = "tl-step pending"; tl3.querySelector(".tl-dot").textContent = "3";
        $("tl-2-note").textContent = "Barista sedang meracik pesananmu";
        $("st-pill").textContent = "Diterima";
        $("status-progress").style.width = "12%";
        state.statusTimers.forEach(clearTimeout); state.statusTimers = [];
        var checkSvg = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>';
        state.statusTimers.push(setTimeout(function(){
          tl2.className = "tl-step active";
          $("st-pill").textContent = "Diproses";
          $("status-progress").style.width = "58%";
        }, 1600));
        state.statusTimers.push(setTimeout(function(){
          tl2.className = "tl-step done"; tl2.querySelector(".tl-dot").innerHTML = checkSvg;
          tl3.className = "tl-step done"; tl3.querySelector(".tl-dot").innerHTML = checkSvg;
          $("st-pill").textContent = "Selesai";
          $("status-progress").style.width = "100%";
          showToast("Pesanan " + state.orderNo + " selesai, diantar ke Meja " + state.table);
        }, 9500));
      }
       
      $("btn-scan-again").addEventListener("click", function(){
        state.statusTimers.forEach(clearTimeout);
        go("screen-scan", "fwd");
      });
      $("btn-sim-scan").addEventListener("click", function(){
        playTransition({
          title: "QR terbaca!",
          steps: ["Membaca kode QR di meja…", "Membuka sesi baru…"],
          duration: 1400
        }, function(){ resetSession(); go("screen-welcome", "fade"); });
      });
      function resetSession(){
        state.cart = []; state.orderNote = ""; state.name = ""; state.table = null;
        $("input-order-note").value = ""; $("input-name").value = "";
        $("welcome-meja").textContent = "Meja";
        var cells = document.querySelectorAll(".table-cell");
        for (var i=0;i<cells.length;i++) cells[i].classList.remove("selected");
        validateWelcome(); syncCartBar(); renderMenu();
      }

      renderMenu();
